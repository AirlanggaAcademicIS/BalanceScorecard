-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 19, 2016 at 03:38 PM
-- Server version: 5.1.37
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `crebas`
--

-- --------------------------------------------------------

--
-- Table structure for table `indikator_proker`
--

CREATE TABLE IF NOT EXISTS `indikator_proker` (
  `ID_INDIKATOR_PROKER` varchar(20) NOT NULL,
  `ID_PROKER` varchar(20) NOT NULL,
  `NAMA_INDIKATOR_PROKER` varchar(20) DEFAULT NULL,
  `STATUS_INDIKATOR_PROKER` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID_INDIKATOR_PROKER`),
  KEY `FK_MEMILIKI1` (`ID_PROKER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `indikator_proker`
--


-- --------------------------------------------------------

--
-- Table structure for table `indikator_tujuan`
--

CREATE TABLE IF NOT EXISTS `indikator_tujuan` (
  `ID_INDIKATOR_TUJUAN` varchar(20) NOT NULL,
  `ID_TUJUAN` varchar(20) NOT NULL,
  `NAMA_INDIKATOR_TUJUAN` varchar(20) DEFAULT NULL,
  `STATUS_INDIKATOR_TUJUAN` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID_INDIKATOR_TUJUAN`),
  KEY `FK_MEMILIKI` (`ID_TUJUAN`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `indikator_tujuan`
--

INSERT INTO `indikator_tujuan` (`ID_INDIKATOR_TUJUAN`, `ID_TUJUAN`, `NAMA_INDIKATOR_TUJUAN`, `STATUS_INDIKATOR_TUJUAN`) VALUES
('1', '1', 'beli', NULL),
('2', '1', 'nyuci', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `karyawan`
--

CREATE TABLE IF NOT EXISTS `karyawan` (
  `NIP` varchar(20) NOT NULL,
  `NAMA` varchar(50) DEFAULT NULL,
  `JABATAN` varchar(20) DEFAULT NULL,
  `PASSWORD` varchar(50) DEFAULT NULL,
  `TANGGAL_LAHIR` date DEFAULT NULL,
  PRIMARY KEY (`NIP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `karyawan`
--

INSERT INTO `karyawan` (`NIP`, `NAMA`, `JABATAN`, `PASSWORD`, `TANGGAL_LAHIR`) VALUES
('1', 'pardi', 'kaprodi', NULL, NULL),
('25', 'andi', 'a', '1234', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `laporan_pertanggung_jawaban`
--

CREATE TABLE IF NOT EXISTS `laporan_pertanggung_jawaban` (
  `ID_LPJ` varchar(30) NOT NULL,
  `ID_PROKER` varchar(20) NOT NULL,
  `EVALUASI` text,
  `KEBERLANJUTAN` text,
  PRIMARY KEY (`ID_LPJ`),
  KEY `FK_MEMPUNYAI2` (`ID_PROKER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `laporan_pertanggung_jawaban`
--

INSERT INTO `laporan_pertanggung_jawaban` (`ID_LPJ`, `ID_PROKER`, `EVALUASI`, `KEBERLANJUTAN`) VALUES
('LPJ_01', '1', 'Kurangnya Dana', 'Tambahan Dana'),
('LPJ_02', '1', 'AAAAA', 'BBBBBBB'),
('LPJ_03', '2', 'RRRRRR', 'CCCCCCC'),
('LPJ_04', '2', 'Dana', 'AAAAAA'),
('LPJ_05', '2', 'Tambahan', 'BBBBB'),
('LPJ_06', '2', 'QQQQQQ', 'PPPPPPP'),
('LPJ_07', '2', 'OPOPOPOP', 'RSRSRSRSRS'),
('LPJ_08', '1', 'EEEEEE', 'ELELELELEL'),
('LPJ_09', '1', 'TYTYTYTY', 'PPWWWQQWQW'),
('LPJ_10', '2', 'WWWWWWWWWW', 'OOOOOOOOO'),
('LPJ_11', '1', 'KKKKKKK', 'KWKWKWKWKW');

-- --------------------------------------------------------

--
-- Table structure for table `menunjang`
--

CREATE TABLE IF NOT EXISTS `menunjang` (
  `ID_INDIKATOR_TUJUAN` varchar(20) NOT NULL,
  `ID_PROKER` varchar(20) NOT NULL,
  PRIMARY KEY (`ID_INDIKATOR_TUJUAN`,`ID_PROKER`),
  KEY `FK_MENUNJANG2` (`ID_PROKER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menunjang`
--

INSERT INTO `menunjang` (`ID_INDIKATOR_TUJUAN`, `ID_PROKER`) VALUES
('1', '1'),
('2', '1'),
('1', '2'),
('2', '2');

-- --------------------------------------------------------

--
-- Table structure for table `proker`
--

CREATE TABLE IF NOT EXISTS `proker` (
  `ID_PROKER` varchar(20) NOT NULL,
  `NIP` varchar(20) NOT NULL,
  `ID_LPJ` varchar(30) DEFAULT NULL,
  `DESKRIPSI` text,
  `NAMA_PROKER` varchar(50) DEFAULT NULL,
  `ANGGARAN_DANA` int(11) DEFAULT NULL,
  `STATUS_PROKER` varchar(10) DEFAULT NULL,
  `LATAR_BELAKANG` text,
  `TUJUAN` text,
  `MEKANISME_DAN_RANCANGAN` text,
  `WAKTU_MULAI_PROKER` date DEFAULT NULL,
  `WAKTU_AKHIR_PROKER` date DEFAULT NULL,
  `PENDAHULUAN` text,
  PRIMARY KEY (`ID_PROKER`),
  KEY `FK_KOORDINATOR` (`NIP`),
  KEY `FK_MEMPUNYAI` (`ID_LPJ`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `proker`
--

INSERT INTO `proker` (`ID_PROKER`, `NIP`, `ID_LPJ`, `DESKRIPSI`, `NAMA_PROKER`, `ANGGARAN_DANA`, `STATUS_PROKER`, `LATAR_BELAKANG`, `TUJUAN`, `MEKANISME_DAN_RANCANGAN`, `WAKTU_MULAI_PROKER`, `WAKTU_AKHIR_PROKER`, `PENDAHULUAN`) VALUES
('1', '1', NULL, NULL, 'kenyang', NULL, NULL, NULL, NULL, NULL, '2016-04-14', '2016-04-30', NULL),
('2', '1', NULL, NULL, 'haha', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tujuan`
--

CREATE TABLE IF NOT EXISTS `tujuan` (
  `ID_TUJUAN` varchar(20) NOT NULL,
  `TUJUAN_ORGANISASI` varchar(50) DEFAULT NULL,
  `PERSPEKTIF` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`ID_TUJUAN`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tujuan`
--

INSERT INTO `tujuan` (`ID_TUJUAN`, `TUJUAN_ORGANISASI`, `PERSPEKTIF`) VALUES
('1', 'makan', 'konsumen');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `indikator_proker`
--
ALTER TABLE `indikator_proker`
  ADD CONSTRAINT `FK_MEMILIKI1` FOREIGN KEY (`ID_PROKER`) REFERENCES `proker` (`ID_PROKER`);

--
-- Constraints for table `indikator_tujuan`
--
ALTER TABLE `indikator_tujuan`
  ADD CONSTRAINT `FK_MEMILIKI` FOREIGN KEY (`ID_TUJUAN`) REFERENCES `tujuan` (`ID_TUJUAN`);

--
-- Constraints for table `laporan_pertanggung_jawaban`
--
ALTER TABLE `laporan_pertanggung_jawaban`
  ADD CONSTRAINT `FK_MEMPUNYAI2` FOREIGN KEY (`ID_PROKER`) REFERENCES `proker` (`ID_PROKER`);

--
-- Constraints for table `menunjang`
--
ALTER TABLE `menunjang`
  ADD CONSTRAINT `FK_MENUNJANG` FOREIGN KEY (`ID_INDIKATOR_TUJUAN`) REFERENCES `indikator_tujuan` (`ID_INDIKATOR_TUJUAN`),
  ADD CONSTRAINT `FK_MENUNJANG2` FOREIGN KEY (`ID_PROKER`) REFERENCES `proker` (`ID_PROKER`);

--
-- Constraints for table `proker`
--
ALTER TABLE `proker`
  ADD CONSTRAINT `FK_KOORDINATOR` FOREIGN KEY (`NIP`) REFERENCES `karyawan` (`NIP`),
  ADD CONSTRAINT `FK_MEMPUNYAI` FOREIGN KEY (`ID_LPJ`) REFERENCES `laporan_pertanggung_jawaban` (`ID_LPJ`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

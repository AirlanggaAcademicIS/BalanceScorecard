<?php  
//membuat koneksi ke database  
$host = 'localhost';  
  $user = 'root';        
  $password = '';        
  $database = 'pengembangansi';    
      
  $konek_db = mysqli_connect($host, $user, $password,$database);      
  //$find_db = mysqli_select_db($database) ;  
?> 